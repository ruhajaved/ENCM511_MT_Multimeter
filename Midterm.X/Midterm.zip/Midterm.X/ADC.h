
#ifndef ADC_H
#define	ADC_H

#include <xc.h> // include header file xc.h

uint16_t do_ADC(uint16_t); // function declaration for do_ADC function

#endif	/* ADC_H */

