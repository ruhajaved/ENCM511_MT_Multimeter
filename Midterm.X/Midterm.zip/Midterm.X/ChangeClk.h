#ifndef CHANGECLK_H
#define	CHANGECLK_H

void NewClk();                  // function declaration for NewClk function
extern unsigned int clkval;     // use global variable clkval

#endif

